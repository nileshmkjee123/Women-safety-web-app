import json
import dash_auth
import dash
import dash_bootstrap_components as dbc
import dash_core_components as dcc
import dash_html_components as html
import numpy as np
import pandas as pd
from dash.dependencies import Input, Output, State
from sklearn.linear_model import LinearRegression
from exp import cards
from card import apps
from classificationProject import classifyByCrime, allCrimes, plotScatterAsCluster2
VALID_USERNAME_PASSWORD_PAIRS = {
    'srm': 'ist'
}
remedies = dict()
with open('./remedy.json', 'r') as file:
    remedies = json.load(file)

regr = LinearRegression()
colors = {
    'background': '#0000',
    'text': '#111111'
}
print(dcc.__version__)  # 0.6.0 or above is required
df = pd.read_csv('wom_dataset.csv')
external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
r = df.iloc[0:36, 0].values
r1 = list(range(2001, 2019))
gc1 = df.columns[0]
gc2 = df.columns[1]
gp = df.groupby(gc1)
state_wise_crime_dict = {state: gp.get_group(state).drop(gc1, axis=1).set_index(gc2) for state in df[gc1].unique()}
state_wise_crime_dict_predicted = {state: None for state in state_wise_crime_dict}
for state in state_wise_crime_dict:
    df_state = state_wise_crime_dict[state]
    df_state.columns = [int(x) for x in df_state.columns]
top_3_dict = dict()
dropLabel = 'TOTAL CRIMES AGAINST WOMEN'
for state, sdf in state_wise_crime_dict.items():
    top_3_df = sdf.mean(axis=1).drop(dropLabel).nlargest(3)
    top_3_dict[state] = top_3_df

state_name_list = sorted(state_wise_crime_dict)
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
auth = dash_auth.BasicAuth(
    app,
    VALID_USERNAME_PASSWORD_PAIRS
)
app.config.suppress_callback_exceptions = True
app.title = 'PREDICTION AND CLASSIFICATION OF CRIMES AGAINST WOMEN IN INDIA '
app.layout = html.Div([

    dcc.Location(id='url', refresh=False),
    html.Div(id='page-content')
])
index_page = html.Div([

     html.H1('PREDICTION AND CLASSIFICATION OF CRIMES AGAINST WOMEN IN INDIA',
            style={'text-align': 'center','font-weight': 'bold','font-size':' xx-large'}),html.Img(src=app.get_asset_url('cc.jpg'), style={'position': 'fixed',
                                                                        'left': '40%',
                                                                        'top': '29%'
                                                                        }),
                       dcc.Link(html.Button('Proceed', id='next', style={'backgroundColor': '#e8f044', 'border-radius': '25px', 'position': 'fixed',
                                                                           'left': '45%', 'top': '90%'}),
                                href='/cards')

])

make_label = lambda x: [{'label': y, 'value': y} for y in x]

valueList = [{'label': r[i], 'value': r[i]} for i in range(0, 36)]
valueList.pop(28) 
page_1_layout = html.Div([
    html.H1('PLEASE SELECT STATE AND CRIME FROM THE DROP DOWN MENU', style={'text-align': 'center','font-weight': 'bold','font-size':' xx-large'}),
    html.Div([

        dcc.Dropdown(
            id='page-1-dropdown',
            options=valueList,
            value=valueList[0]['value'],
            placeholder="Select a place",
        ),

        dcc.Dropdown(
            id='page-1-dropdown_crime',
            options=make_label(df[gc2].unique()),
            value=make_label(df[gc2].unique())[0]['value'],
            placeholder="Select a crime",
        ),
        dcc.Graph(id='graph')],
    ),
    html.Br(),
    html.Div([
       dcc.Link(html.Button('Next Page', id='next', style={'backgroundColor': '#e8f044', 'border-radius': '25px', 'position': 'fixed',
                                                                           'left': '47%', 'top': '90%'}),
                 href='/crime-wise'),
        html.Div(id='body-div')
    ]),
    html.Div(id='page-1-content'),
    html.Br(),
    html.Div(id='graph-display'),
  

])


def make_item(state):
    # we use this function to make the example items to avoid code duplication
    max_crimes = top_3_dict[state]
    return [dbc.Card(
        [
            dbc.CardHeader(
                html.H2(
                    dbc.Button(
                        f"{index}",
                        color="link",
                        id=f"group-{i}-toggle",
                    )
                )
            ),
            dbc.Collapse(
                dbc.CardBody([
                    html.P(f"Remedy 1 for crime {i}"),
                    html.P(f"Remedy 2 for crime {i}"),
                    html.P(f"Remedy 3 for crime {i}"),

                ]),
                id=f"collapse-{i}",
            ),
        ]
    ) for i, index in enumerate(max_crimes.index)]


def make_dropDowns(state):
    top3crimes = top_3_dict[state]
    out = [
        dcc.Dropdown(
            options=[
                {'label': remedies[index]["1"], 'value': str(i)},
                {'label': remedies[index]["2"], 'value': str(i)},
                {'label': remedies[index]["3"], 'value': str(i)}
            ],
            placeholder="{}".format(index),
            value=state,
        )
        for i, index in enumerate(top3crimes.index)]
    return out


def make_tabs(state):
    top3crimes = top_3_dict[state]
    crimes = list(top3crimes.index)
    out = html.Div([
        dcc.Tabs(id="tabs", value=crimes[0], children=[
            dcc.Tab(label=index, value=index) for i, index in enumerate(crimes)
        ]),
        html.Div(id='tabs-content')
    ])
    return out


@app.callback(Output('tabs-content', 'children'),
              [Input('tabs', 'value')])
def render_content(tab):
    remlist = remedies[tab]
    return html.Div(children=html.Ol(children=[
        html.Li(remlist[str(i)]) for i in range(1, 4)
    ]))


@app.callback([dash.dependencies.Output('graph', 'figure')],
              [dash.dependencies.Input('page-1-dropdown', 'value'),
               dash.dependencies.Input('page-1-dropdown_crime', 'value'), ])
def page_1_dropdown(state, crime):
    data_y = np.array(state_wise_crime_dict[state].loc[crime])
    data_x = np.array(state_wise_crime_dict[state].columns)
    data_x_predict = np.array(list(range(2001, 2021)))
    d2 = lambda x: [[y] for y in x]
    data_y_predict = regr.fit(d2(data_x), data_y).predict(d2(data_x_predict))
    out = make_dropDowns(state)

    graphData = {
        'data': [
            dict(
                x=data_x, y=data_y, mode='markers', name='Observed', marker=dict(
                    color='blue',
                )
            ),

            dict(
                x=data_x_predict, y=data_y_predict, name='Predicted', marker=dict(
                    color='red'
                )
            ),

        ],
        'layout': dict(
            title='Variations in crime rate ({}) of {}'.format(crime, state),
            legend=dict(
                x=0,
                y=1.0
            ),

        )
    }
    return [graphData]


page_2_layout = html.Div([html.H1('PLEASE SELECT A STATE FROM THE DROP DOWN MENU', style={'text-align': 'center','font-weight': 'bold','font-size':' xx-large'}),
 

                          dcc.Dropdown(
                              id='page-2-dropdown',
                              options=valueList,
                              value=valueList[0]['value'],

                              placeholder="Select a place",

                          ),
                          dcc.Graph(id='graph2'),html.H1('REMEDIES', style={'text-align': 'center','font-weight': 'bold','font-size':' xx-large'}),
                          dbc.Col(html.Div(id='maxcrimes')),
                          dcc.Link(html.Button('Next Page', id='next', style={'backgroundColor': '#e8f044', 'border-radius': '25px', 'position': 'fixed',
                                                                           'left': '45%', 'top': '95%'}),
                                href='/apps')
                          ])


@app.callback([dash.dependencies.Output('maxcrimes', 'children'),
               dash.dependencies.Output('graph2', 'figure')],
              [dash.dependencies.Input('page-2-dropdown', 'value'),
               ])
def page_2_stae_dropdown(state):
    out = make_dropDowns(state)
    out = make_tabs(state)
    series = top_3_dict[state]
    crimes = list(series.index)
    values = list(series.values)
    colors = ['#FF0000', '#111111', '#0000FF']
    graphData = {
        'data': [
            {'y': [values[i]], 'x': [i], 'type': 'bar', 'name': crimes[i], "marker": {"color": colors[i]}} for i in
            range(len(crimes))

        ],
        'layout': {
            'title': 'Top 3 Crime in {}'.format(state),
            'xaxis': {
                "automargin": True,
                "title": {"text": "Crime"}
            },
            'yaxis': {
                "automargin": True,
                "title": {"text": "Average Crime Rate"}
            }

        }
    }
    return [out, graphData]


@app.callback(
    [Output(f"collapse-{i}", "is_open") for i in range(1, 4)],
    [Input(f"group-{i}-toggle", "n_clicks") for i in range(1, 4)],
    [State(f"collapse-{i}", "is_open") for i in range(1, 4)],
)
def toggle_accordion(n1, n2, n3, is_open1, is_open2, is_open3):
    ctx = dash.callback_context

    if not ctx.triggered:
        return ""
    else:
        button_id = ctx.triggered[0]["prop_id"].split(".")[0]

    if button_id == "group-1-toggle" and n1:
        return not is_open1, False, False
    elif button_id == "group-2-toggle" and n2:
        return False, not is_open2, False
    elif button_id == "group-3-toggle" and n3:
        return False, False, not is_open3
    return False, False, False


allCrimeDropDowns = html.Div([
    html.H1('PLEASE SELECT A CRIME FROM THE DROP DOWN MENU', style={'text-align': 'center','font-weight': 'bold','font-size':' xx-large'}),
    html.Div([

        dcc.Dropdown(
            id='crime',
            options=make_label(allCrimes),
            value=make_label(allCrimes)[0]['value'],
            placeholder="Select a crime",
        ),
        dcc.Graph(id='graph_class'),dcc.Link(html.Button('Next Page', id='next', style={'backgroundColor': '#e8f044', 'border-radius': '25px', 'position': 'fixed',
                                                                           'left': '45%', 'top': '95%'}),
                                href='/page-2')
        
        ],
    )
])


@app.callback(Output('graph_class', 'figure'),
              [Input('crime', 'value')])
def render_content_classify(crime):
    safe, unsafe, cutoff = classifyByCrime(crime)
    graphData = {
        'data': [

            dict(
                x=safe['STATE'], y=safe[crime], type='bar', mode='markers',
                marker=dict(
                    color='yellow',
                ),
                name='SAFE'
            ),
            dict(
                x=unsafe['STATE'], y=unsafe[crime], type='bar', mode='markers',
                marker=dict(
                    color='red',
                )
                ,
                name='UNSAFE'
            ),

        ],
        'layout': dict(
            title='States classified for crime {}'.format(crime),
            legend=dict(
                x=0,
                y=1.0,
                name='Animesh'
            ),
            yaxis={
                "automargin": True,
                "title": {"text": "Average Crime Rate in 12 years"}
            },

        )
    }
    return graphData


classifcation_layout = allCrimeDropDowns

allCrimeDropDownsByCrime = html.Div([
    html.H1('PLEASE SELECT A CRIME FROM THE DROP DOWN MENU', style={'text-align': 'center','font-weight': 'bold','font-size':' xx-large'}),
    html.Div([

        dcc.Dropdown(
            id='crime_crime',
            options=make_label(allCrimes),
            value=make_label(allCrimes)[0]['value'],
            placeholder="Select a crime",
        ),
        dcc.Graph(id='graph_class_crime'), dcc.Link(html.Button('Next Page', id='next', style={'backgroundColor': '#e8f044', 'border-radius': '25px', 'position': 'fixed',
                                                                           'left': '45%', 'top': '95%'}),
                                href='/page-2')],
       
    ),
])


@app.callback(Output('graph_class_crime', 'figure'),
              [Input('crime_crime', 'value')])
def render_content_classify_by_crime(crime):
    nclusters = 3
    xdata, ydata, labels, state_crime, lableTupleList, data_dictionary = plotScatterAsCluster2(crime, nclusters)
    color = ['#0000FF', '#FF0000', '#00FF00']
    dataList = []
    for i in range(nclusters):
        label = i
        data = data_dictionary[i]
        element = dict(
                x=data['xdata'], y=data['ydata'], mode='markers',
                marker=dict(color=color[label]),
                text=state_crime[label],
                hovertemplate=
                "<b>%{text}</b><br><br>" +
                "Year: %{x:0f}<br>" +
                "Crime Record: %{y:0f}<br>" +
                "<extra></extra>",
                hovertext=state_crime[label],
                hoverinfo="text",
                hoverlabel_align='right',
                name='Region-{}'.format(label)
            )
        dataList.append(element)

    graphData = {
        'data':dataList,
        'layout': dict(
            title='2001-12 year classification for crime {}'.format(crime),
            legend=dict(
                x=0,
                y=1.0,
                name='Animesh'
            ),
            yaxis={
                "automargin": True,
                "title": {"text": "Crime classification in 12 years"}
            },
            hovermode="closest"

        )
    }
    return graphData


classification_by_crime = allCrimeDropDownsByCrime


# Update the index
@app.callback(dash.dependencies.Output('page-content', 'children'),
              [dash.dependencies.Input('url', 'pathname')])
def display_page(pathname):
    if pathname == '/page-1':
        return page_1_layout
    elif pathname == '/page-2':
        return page_2_layout
    elif pathname == '/cards':
        return cards
    elif pathname == '/crime-wise':
        return classification_by_crime
    elif pathname == '/apps':
        return apps
    else:
        return index_page
    # You could also return a 404 "URL not found" page here


if __name__ == '__main__':
    app.run_server(debug=True)
