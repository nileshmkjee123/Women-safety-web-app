import dash_bootstrap_components as dbc
import dash_html_components as html
import dash
import dash_core_components as dcc
from dash.dependencies import Input, Output, State
#app = dash.Dash(external_stylesheets=[dbc.themes.BOOTSTRAP])

apps =  html.Div(
   [ html.H1("SOME APPLICATIONS FOR MOBILE SAFETY", style={'text-align': 'center','font-weight': 'bold','font-size':' xx-large'}),
    dbc.ListGroup(
    [
        dbc.ListGroupItem(
            [
                  dcc.Link(dbc.ListGroupItemHeading("My Safetipin"),href='http://safetipin.com/'),
                dbc.ListGroupItemText("Mysafetipin is a map-based safety app, which tells you about the safety of the place you are going, the safety of the location is shown by colors, red color indicates the ‘unsafe’ area, green color is for ‘safe’, and amber for ‘less safe’. The safety score of a place based on 9 parameters, lighting, openness, visibility, people, security, walk path, gender usage, feeling and The app also tells you about the public transport availability in the area, whether there is a police station, pharmacy or ATM nearby, it also allows you to share your real-time location via GPS tracking, with your friends or family."),
            ]
        ),
        dbc.ListGroupItem(
            [
                 dcc.Link(dbc.ListGroupItemHeading("Citizencop"),href='http://www.citizencop.org/'),
                dbc.ListGroupItemText("CitizenCOP is a location-based safety app, which provides you a hassle-free and easy way for crime reporting. The app as developed by INFOCRATS for a clean and safer society and help develop a healthy living environment. You can report any criminal incident or illegal activity anonymously, Make emergency calls or send alerts, call the police, allow loved ones to track your location with live tracking, emergency calls, and Sos alerts. You can use the app in most of the major cities in the country."),
            ]
        ),
         dbc.ListGroupItem(
            [
                 dcc.Link(dbc.ListGroupItemHeading("Himmat"),href='https://digitalindia.gov.in/content/himmat-app'),
                dbc.ListGroupItemText("Himmat was launched by Delhi Police due to the increasing crime in the city, one of the major features of the app is that you can send your exact location with audio and video of the surroundings to Delhi police control room, the Delhi Police can then immediately send the nearest Police help to the victim. The app has a user-friendly interface and is pretty easy to use, to register you need to enter your mobile number, you will then receive an OTP for verification."),
            ]
        ),
        dbc.ListGroupItem(
            [
                dcc.Link(dbc.ListGroupItemHeading("Shake2Safety"),href='https://play.google.com/store/apps/details?id=com.photon.shake2safety&hl=en_IN'),
                dbc.ListGroupItemText("Shake2safety is one of the easiest and simplest apps to use, all you need to do is shake your smartphone or press the power button, and this will instantly send an SOS message to the registered mobile numbers. One of the best features of this app is that it works without the internet too; the app also allows you to report robbery, accident or any natural disaster."),
            ]
        ),
         dbc.ListGroupItem(
            [
                dcc.Link(dbc.ListGroupItemHeading("Eyewatch SOS for Women"),href='https://eye-watch.in/Login.action'),
                dbc.ListGroupItemText("Eyewatch is a great app for women safety because it captures audio and video of the users surrounding and sends it to the registered contacts with an alert message, the great thing about the app is that it is highly accurate and it can function even without GPRS, another feature of the app is that once you are safe, you can notify the registered numbers with the I am safe button."),
            ]
        ),
        dbc.ListGroupItem(
            [
                dcc.Link(dbc.ListGroupItemHeading("Family Locator – Gps Tracker"),href='https://family-locator.com/index.html'),
                dbc.ListGroupItemText("Family Locator is a safety app, which can be used by your entire family, it is one of the best safety apps which allows you to connect with all your family members. You can create your private groups called circles, and view the real-time location of Circle Members on a private family map that’s only visible to your Circle. You receive real-time alerts when your family members arrive or leave a destination. You can also see the location of lost phones using the app. The app works in such a way that your entire family stays connected and feels safe."),
            ]
        ),
         dbc.ListGroupItem(
            [
                dcc.Link(dbc.ListGroupItemHeading("Bsafe"),href='https://getbsafe.com/'),
                dbc.ListGroupItemText("If you are looking for a safety app, which has different features, then safe should be on the top of your list, the app has a bSafe alarm which sends exact location of the user, and audio-video of the surrounding areas to the emergency contacts selected by the user. Another feature which the app has is called Follow me, which enables virtual tracking by GPS. Fake call feature allows you to get out of unwanted situations and the timer alarm feature helps you set an auto alarm to keep your contacts informed about your location."),
            ]
        ),
        dbc.ListGroupItem(
            [
                dcc.Link(dbc.ListGroupItemHeading("112 App"),href='https://play.google.com/store/apps/details?id=in.cdac.ners.psa.mobile.android.national&hl=en_IN'),
                dbc.ListGroupItemText("The 112 SOS Mobile App is a part of the Emergency Response Support System (ERSS), the app is a Government of India initiative. Just by pressing a button, you can activate the app, then the App will send emergency alerts with the user’s details(name, age, emergency contacts) and location information, along with a generated call to ‘112’ – to the State Emergency Control Room and the person’s emergency contacts. The system forwards the emergency alert to nearby online local volunteers if available. The emergency alert is notified with an audible sound/ visual alert on the volunteer smartphone."),
            ]
        ),
         dbc.ListGroupItem(
            [
                 dcc.Link(dbc.ListGroupItemHeading("Smart24x7"),href='https://play.google.com/store/apps/details?id=smart.emergencyservice&hl=en_IN'),
                dbc.ListGroupItemText("Smart 24×7 is a security app which alerts emergency contacts with your location, you can also call the police using the panic button in the app, if the GPRS is not functioning, then the location is sent via Sms, the app also clicks photos and records audio-video of situation. You can get instant help from the nearest Police, Hospitals, Fire using this app, the app also has a Use Fake Call feature to walk out of any difficult situation. The app is currently supported by Gurgaon Police, Jalandhar Police, Chandigarh Police, Jammu Police, Mohali Police, UP Fire Services(Lucknow& Noida)."),
            ]
        ),
        dbc.ListGroupItem(
            [
                 dcc.Link(dbc.ListGroupItemHeading("Chilla"),href='https://play.google.com/store/apps/details?id=comm.Kishlay.screamDetector&hl=en_IN'),
                dbc.ListGroupItemText("Chilla is a safety app, which uses different approach for identifying emergencies, if you are ever stuck in a situation where you cannot use your phone or press the button of the phone, you can activate the app just by shouting, the app is activated when a scream is heard or by pressing the power button 5 times, the app then sends an alert message to the woman’s guardian or automatically places a call. the user’s location and recording can be immediately sent without even unlocking the phone. The app can also be used for emergencies like a heart attack."),
            ]
        ),
    ], 

), dcc.Link(html.Button('Back to Home', id='next', style={'backgroundColor': '#e8f044', 'border-radius': '25px', 'position': 'fixed',
                                                                           'left': '47%', 'top': '90%'}),
                 href='/index_page'),
   ]
)
