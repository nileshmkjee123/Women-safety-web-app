import pandas as pd
import numpy as np
import warnings
from sklearn.cluster import KMeans
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
import seaborn as sns

sns.set()
df = pd.read_csv('wom_dataset.csv')

columns = list(df.columns)
columns[0] = 'STATE'
columns[1] = 'CRIME'
df.columns = columns
dateCols = columns[2:]
df['full'] = df.apply(lambda row: sum(row.loc[dateCols]), axis=1)
totalColumns = [x for x in df['STATE'].unique() if x.startswith('TOTAL')]
total = totalColumns[-1]

allStates = [x for x in df['STATE'].unique() if not x.startswith('TOTAL')]
allCrimes = [x for x in df['CRIME'].unique() if not x.startswith('TOTAL')]

statecrime = df.pivot(index='STATE', columns='CRIME', values='full')
totalCounts = statecrime.loc[total]
statecrime /= totalCounts
onlystatecrime = statecrime.drop(totalColumns)


def plotCrime(crime):
    import matplotlib.pyplot as plt
    data = onlystatecrime.loc[:, crime].reset_index()
    data['STATEINDEX'] = list(range(data.shape[0]))
    data.plot.scatter(x='STATEINDEX', y=crime, title=crime)
    plt.show()


def classifyByCrime(crime, knn=2):
    data = onlystatecrime.loc[:, crime].reset_index()
    data['STATEINDEX'] = list(range(data.shape[0]))
    stateDict = {i: data.loc[i, 'STATE'] for i in data['STATEINDEX']}
    cutoff = data[crime].median()
    data['LABEL'] = data.apply(lambda row: int(row[crime] > cutoff), axis=1)
    X = data[['STATEINDEX', crime]]
    y = pd.Categorical.from_codes(data['LABEL'], ['SAFE', 'UNSAFE'])
    y = pd.get_dummies(y, drop_first=True)

    # doing the classification
    X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=1)
    knn = KNeighborsClassifier(n_neighbors=knn, metric='euclidean')
    knn.fit(X_train, y_train)
    y_pred = knn.predict(X_test)
    X_test['UNSAFE'] = y_pred
    tested = X_test
    trained = X_train.join(y_train, how='outer')
    trained['UNSAFE'] = trained.apply(lambda row: int(row.loc['UNSAFE'] > cutoff), axis=1)

    plotData = pd.concat([tested, trained]).sort_index()

    plotData['STATE'] = plotData.apply(lambda row: stateDict.get(row.loc['STATEINDEX']), axis=1)
    plotData['UNSAFE'] = plotData.apply(lambda row: int(row.loc[crime] > cutoff), axis=1)

    safe = plotData[plotData['UNSAFE'] == 0]
    unsafe = plotData[plotData['UNSAFE'] == 1]
    return safe, unsafe, cutoff


def plotScatterAsCluster2(crime, nclusters=3):
    df = pd.read_csv('wom_dataset.csv')
    columns = list(df.columns)
    columns[0] = 'STATE'
    columns[1] = 'CRIME'
    df.columns = columns

    #print('Calculating for  crime {}'.format(crime))
    x = list(range(2001, 2013))
    xstr = [str(j) for j in x]
    X = []
    X_with_states = []
    state_crime_dictionary = {}
    data_dictionary = {}
    totalColumns = [x for x in df['STATE'].unique() if x.startswith('TOTAL')]
    dfs = df[df['CRIME'].eq(crime) & ~df['STATE'].isin(totalColumns)].loc[:, ['STATE'] + xstr]

    for p in dfs.index:
        state = dfs.loc[p, 'STATE']
        series = dfs.loc[p, xstr].values
        X += [[i, j] for i, j in zip(series, x)]
        X_with_states += [[i, j, state] for i, j in zip(series, x)]
    kmeans = KMeans(n_clusters=nclusters, random_state=0).fit(X)
    labels = kmeans.labels_

    ydata = [z[0] for z in X]
    xdata = [z[1] for z in X]
    labelTupleList = [(X_with_states[i][2], X_with_states[i][1]) for i in range(len(xdata))]
    for i, labelValue in enumerate(labels):
        if labelValue not in state_crime_dictionary:
            state_crime_dictionary[labelValue] = []
        state_crime_dictionary[labelValue].append(
            # '{}\n-{}\n-{}'.format(X_with_states[i][2], X_with_states[i][1], X_with_states[i][0])
            '{}'.format(X_with_states[i][2])

        )

        if labelValue not in data_dictionary:
            data_dictionary[labelValue] = {'xdata': [], 'ydata': []}

        data_dictionary[labelValue]['xdata'].append(xdata[i])
        data_dictionary[labelValue]['ydata'].append(ydata[i])

    return xdata, ydata, labels, state_crime_dictionary, labelTupleList, data_dictionary


if __name__ == '__main__':
    df = classifyByCrime(allCrimes[3], 2)
