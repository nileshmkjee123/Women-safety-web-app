import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
import seaborn as sns


def plotScatterAsCluster2(crime, nclusters=3):
    df = pd.read_csv('wom_dataset.csv')
    columns = list(df.columns)
    columns[0] = 'STATE'
    columns[1] = 'CRIME'
    df.columns = columns

    colorMap = {i: color for i, color in enumerate(['#0000FF', '#FF0000', '#00FF00'])}
    print('Calculating for  crime {}'.format(crime))
    x = list(range(2001, 2013))
    xstr = [str(j) for j in x]
    X = []
    X_with_states = []
    state_crime_dictionary = {}
    totalColumns = [x for x in df['STATE'].unique() if x.startswith('TOTAL')]
    dfs = df[df['CRIME'].eq(crime) & ~df['STATE'].isin(totalColumns)].loc[:, ['STATE'] + xstr]

    for p in dfs.index:
        state = dfs.loc[p, 'STATE']
        series = dfs.loc[p, xstr].values
        X += [[i, j] for i, j in zip(series, x)]
        X_with_states += [[i, j, state] for i, j in zip(series, x)]
    kmeans = KMeans(n_clusters=nclusters, random_state=0).fit(X)
    labels = kmeans.labels_
    #     print('The labels are {}'.format(labels))
    #     print(X)
    ydata = [z[0] for z in X]
    xdata = [z[1] for z in X]
    colors = [colorMap[i] for i in labels]
    legends = ['Region-{}'.format(i) for i in range(nclusters)]
    for i, labelValue in enumerate(labels):
        if labelValue not in state_crime_dictionary:
            state_crime_dictionary[labelValue] = []
        state_crime_dictionary[labelValue].append((X_with_states[i][2], X_with_states[i][1]))
    for label, value in state_crime_dictionary.items():
        print('Label = {}'.format(label))
        print('States = {}'.format(value))
    plt.scatter(x=xdata, y=ydata, c=colors)
    plt.xlabel('Timeline')
    plt.ylabel('No of {} crimes, 2001-12'.format(crime))
    plt.title(label='Classification')
    plt.legend(loc='upper left')
    plt.show()


if __name__ == '__main__':
    sns.set()
    df = pd.read_csv('wom_dataset.csv')
    columns = list(df.columns)
    columns[0] = 'STATE'
    columns[1] = 'CRIME'
    df.columns = columns

    allStates = [x for x in df['STATE'].unique() if not x.startswith('TOTAL')]
    allCrimes = [x for x in df['CRIME'].unique() if not x.startswith('TOTAL')]
    plotScatterAsCluster2(allCrimes[0])
