import dash
import dash_bootstrap_components as dbc
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
from classificationProject import  allCrimes
#app = dash.Dash(external_stylesheets=[dbc.themes.BOOTSTRAP])


p='Definition'
# define content for page 1
cards =html.Div(
    [html.H1("BASIC INFORMATION ABOUT THE CRIMES"
            , style={'text-align': 'center','font-weight': 'bold','font-size':' xx-large'}),

        dbc.Row(
            [
                dbc.Col(dbc.Card([
    dbc.CardHeader(allCrimes[0]),
    dbc.CardBody(
        [
            html.H5(p, className="card-title"),
           
            html.P(
               "Rape is a type of sexual assault usually involving sexual intercourse or other forms of sexual penetration carried out against a person without that person's consent",className="card-text",
            ), dbc.DropdownMenu(
    label="Punishment",color="dark",
    children=[
       html.P("Whoever  takes advantage of his official position and commits rape on a woman  shall be punished with imprisonment of either description for a term which shall not be less than seven years but which may be for life or for a term which may extend to ten years and shall also be liable to fine .",
                className="card-text",)
    ],
    direction="right"
),
        ]
    ),
], color="primary", inverse=True)),
 dbc.Col(dbc.Card([
    dbc.CardHeader(allCrimes[1]),
    dbc.CardBody(
        [
            html.H5(p, className="card-title"),
             html.P(
               "If any person takes a person beyond the limits of India against the consent of that person or against the consent of someone who is legally entitled to give consent on that person’s behalf, then the offence of kidnapping from India is committed",className="card-text",
            ), dbc.DropdownMenu(
    label="Punishment",color="dark",
    children=[
       html.P("If a person is kidnapped or abducted by a person then that person is punishable with imprisonment for life or rigorous imprisonment for a term up to 10 years and a fine.")
    ],direction="right"
),
        ]
    ),
], color="secondary", inverse=True)),
              dbc.Col(dbc.Card([
    dbc.CardHeader(allCrimes[2]),
    dbc.CardBody(
        [
            html.H5(p, className="card-title"),
            html.P(
               "If a woman dies within seven years of marriage by any burns or bodily injury or it was revealed that before her marriage she was exposed to cruelty or harassment by her husband or any other relative of the husband in connection to demand dowry then the death of the woman will be considered as a dowry death.",className="card-text",
            ), dbc.DropdownMenu(
    label="Punishment",color="dark",
    children=[
       html.P("Punishment for dowry death is a minimum sentence of imprisonment for seven years or a maximum sentence of imprisonment for life.")
    ],direction="right"
),
        ]
    ),
], color="warning", inverse=True)),

            ],
            className="mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(dbc.Card([
    dbc.CardHeader(allCrimes[3]),
    dbc.CardBody(
        [
            html.H5(p, className="card-title"),
            html.P(
               "It is a special crime to use force against a woman, or even threaten to use force, if the intention is to 'outrage her modesty'. It treats it more seriously than normal and criminal force by allowing the police to make arrests for such crimes without a warrant.",className="card-text",
            ), dbc.DropdownMenu(
    label="Punishment",color="dark",
    children=[
       html.P("The punishment is jail time of between one and three years along with a fine. If someone is found guilty of committing the same crime more than one time, the punishment is jail time of between three and seven years along with a fine.")
    ],direction="right"
),
        ]
    ),
], color="danger", inverse=True)),
 dbc.Col(dbc.Card([
    dbc.CardHeader(allCrimes[6]),
    dbc.CardBody(
        [
            html.H5(p, className="card-title"),
            html.P(
               "It is importing of girls under the age of twenty-one years with intent of forced or seduced  illicit intercourse with another person (knowingly or unknowingly) into India from any country outside India or from the State of Jammu and Kashmir , ",className="card-text",
            ), dbc.DropdownMenu(
    label="Punishment",color="dark",
    children=[
       html.P("The punishment is  imprisonment which may extend to ten years and shall also be liable to fine.")
    ],direction="right"
            ),
        ]      
    ),
], color="success", inverse=True)),
              dbc.Col(dbc.Card([
    dbc.CardHeader(allCrimes[5]),
    dbc.CardBody(
        [
            html.H5(p, className="card-title"),
            html.P(
               "It is defined as any wilful conduct which is of such a nature as is likely to drive the woman to commit suicide or to cause grave injury or danger to life, limb or health (whether mental or physical) of the woman by husband or the relative of the husband",className="card-text",
            ), dbc.DropdownMenu(
    label="Punishment",color="dark",
    children=[
       html.P("It can result in imprisonment for a term which may extend to three years and shall also be liable to fine. ")
    ],direction="right"
),
        ]
    ),
], color="info", inverse=True)),

            ],
            className="mb-4",
        ),
 dbc.Row(
            [
                dbc.Col(dbc.Card([
    dbc.CardHeader(allCrimes[4]),
    dbc.CardBody(
        [
            html.H5(p, className="card-title"),
            html.P(
               " If a person utters any words, makes any sound or gesture, or exhibits any object, intending that such word or sound shall be heard, or that such gesture or object shall be seen, by a woman, or intrudes upon the privacy of a woman,",className="card-text",
            ), dbc.DropdownMenu(
    label="Punishment",color="dark",
    children=[
       html.P("Punishment can be simple imprisonment for a term which may extend to three years, and also with fine.")
    ],direction="right"
),
        ]
    ),
], color="success", inverse=True)),
 dbc.Col(dbc.Card([
    dbc.CardHeader(allCrimes[7]),
    dbc.CardBody(
        [
            html.H5(p, className="card-title"),
            html.P(
               " It is defined as any act or assistance in the keeping or management of a brothel which usually are responsible for trafficking of women  ",className="card-text",
            ), dbc.DropdownMenu(
    label="Punishment",color="dark",
    children=[
       html.P("Punishment can be imprisonment for a term which may extend to seven years, or with fine which may extend to one thousand rupees, or with both .")
    ],direction="right"
),
        ]
    ),
], color="secondary", inverse=True)),
              dbc.Col(dbc.Card([
    dbc.CardHeader(allCrimes[8]),
    dbc.CardBody(
        [
            html.H5(p, className="card-title"),
            html.P(
               "It defines dowry as any property or valuable security directly or indirectly agreed to be given by one party for marriage to the other party  or by the parent of either party or by any other person, to either party for the marriage ",className="card-text",
            ), dbc.DropdownMenu(
    label="Punishment",color="dark",
    children=[
       html.P("Punishment can be imprisonment for a term which shall not be less than five years, and with the fine which shall not be less than fifteen thousand rupees or the amount of the value of such dowry, whichever is more")
    ],direction="right"
),
        ]
    ),
], color="warning", inverse=True)),

            ],
            className="mb-4",
        ),
 dbc.Row(
            [
                dbc.Col(dbc.Card([
    dbc.CardHeader(allCrimes[9]),
    dbc.CardBody(
        [
            html.H5(p, className="card-title"),
            html.P(
               "It is defined as production, selling , hiring, distribution, circulation or sending by post any book, pamphlet, paper, slide, film, writing, drawing, painting, photograph, representation or figure which contains indecent representation of women in any form.",className="card-text",
            ), dbc.DropdownMenu(
    label="Punishment",color="dark",
    children=[
       html.P("Imprisonment for term of not less than six months but which may extend to five years and also with a fine not less than ten thousand rupees but which may extend to one lakh rupees.")
    ],direction="right"
),
        ]
    ),
], color="primary", inverse=True)),
 dbc.Col(dbc.Card([
    dbc.CardHeader(allCrimes[10]),
    dbc.CardBody(
        [
            html.H5(p, className="card-title"),
           html.P(
               " It is defined as the act or custom of a  widow burning herself to death or being burned to death on the funeral pyre of her husband",className="card-text",
            ), dbc.DropdownMenu(
    label="Punishment",color="dark",
    children=[
       html.P("Imprisonment for a term which shall not be less than one year but which may extend to seven years and with fine which shall not be less than five thousand rupees but which may extend to thirty thousand rupees.")
    ],direction="right"
),
        ]
    ),
], color="secondary", inverse=True)),
              
            ],
            className="mb-4",
        ),
dcc.Link(html.Button('Next Page', id='next', style={'backgroundColor': '#e8f044', 'border-radius': '25px', 'position': 'fixed',
                                                                           'left': '45%', 'top': '95%'}),
                                href='/page-1')
    ]
)




