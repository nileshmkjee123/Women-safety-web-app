import json

resDict = {}


class Parser():

    def __init__(self):
        self.lasKey = None

    def parse(self, line):
        if line == '\n':
            return
        elif line[0].isdigit() is True:
            num = int(line[0])
            resDict[self.lastKey][num] = line[2:].lstrip().rstrip()
        else:
            if line.endswith('\n'):
                key = line[:-1]
                resDict[key] = dict()
                self.lastKey = key


parser = Parser()
with open('./remedy.txt') as file:
    for i, line in enumerate(file):
        parser.parse(line)

print('Done')

with open('./remedy.json', 'w+') as file:
    json.dump(resDict, file)
